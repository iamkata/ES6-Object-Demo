var that;
class Tab {
    constructor(id) {
        //that指向的是tab示例对象
        that = this;
        // 整个 tab 界面
        this.main = document.querySelector(id);
        // 添加按钮
        this.add = this.main.querySelector('.tabadd');
        // li的父元素
        // 获取fisrstnav的第一个孩子ul，使用了css3选择器
        this.ul = this.main.querySelector('.fisrstnav ul:first-child'); 
        // section 父元素
        this.fsection = this.main.querySelector('.tabscon');
        // 初始化代码
        this.init();
    }

    //获取元素节点,绑定事件
    init() {
      //获取所有元素节点
      this.updateNode();
      // init 初始化操作让相关的元素绑定事件
      this.add.onclick = this.addTab;
      for (var i = 0; i < this.lis.length; i++) {
        this.lis[i].index = i; // 保存 index,留着以后确定是哪个按钮
        this.lis[i].onclick = this.toggleTab; // 点击 tab
        this.remove[i].onclick = this.removeTab; // 点击 x
        this.spans[i].ondblclick = this.editTab; // 双击 tab 事件
        this.sections[i].ondblclick = this.editTab; //双击下面的 section 事件
      }
    }

    // 因为我们动态添加元素 需要从新获取对应的元素
    updateNode() {
      this.lis = this.main.querySelectorAll('li');
      this.sections = this.main.querySelectorAll('section');
      this.remove = this.main.querySelectorAll('.icon-guanbi');
      // 选取fisrstnav里面的li，li里面的第一个span，就是标题span
      this.spans = this.main.querySelectorAll('.fisrstnav li span:first-child'); 
    }

    // 1. 切换功能
    toggleTab() {
      // console.log(this.index);
      that.clearClass();
      this.className = 'liactive';
      //that代表tab示例对象 this代表响应这个方法的按钮
      that.sections[this.index].className = 'conactive';
    }

    // 清除所有 li 和 section 的类
    clearClass() {
      for (var i = 0; i < this.lis.length; i++) {
        this.lis[i].className = '';
        this.sections[i].className = '';
      } 
    }

    // 2. 添加功能
    addTab() {
      // 先清除所有的类
      that.clearClass();
      // (1) 创建li元素和section元素 
      var random = Math.random();
      // 设置为默认选中状态
      var li = '<li class="liactive"><span>新选项卡</span><span class="iconfont icon-guanbi"></span></li>';
      var section = '<section class="conactive">测试 ' + random + '</section>';
      // (2) 把这两个元素追加到对应的父元素里面的最后面
      that.ul.insertAdjacentHTML('beforeend', li);
      that.fsection.insertAdjacentHTML('beforeend', section);
      that.init(); //重新获取所有的小li和section，然后重新绑定事件
    }

    // adjacent 邻近的
    // element.insertAdjacentHTML(position, text);
    // position
    // 一个 DOMString，表示插入内容相对于元素的位置，并且必须是以下字符串之一：
    // 'beforebegin'：元素自身的前面。
    // 'afterbegin'：插入元素内部的第一个子节点之前。
    // 'beforeend'：插入元素内部的最后一个子节点之后。 最常用
    // 'afterend'：元素自身的后面。
    // text
    // 是要被解析为HTML或XML元素，并插入到DOM树中的 DOMString。

    // 3. 删除功能
    removeTab(e) {
      e.stopPropagation(); // 阻止冒泡 防止触发li 的切换点击事件
      var index = this.parentNode.index; 
      console.log(index);
      // 根据索引号删除对应的li 和section   remove()方法可以直接删除指定的元素，就不用removeChild了
      that.lis[index].remove();
      that.sections[index].remove();
      that.init();
      // 当我们删除的不是选中状态的li 的时候,原来的选中状态li保持不变
      if (document.querySelector('.liactive')) return; //有这个类就说明有选中状态，就直接return
      // 当我们删除了选中状态的这个li 的时候, 让它的前一个li 处于选定状态
      index--;
      // 手动调用我们的点击事件 不需要鼠标触发
      // 如果前面为真，就执行后面的调用，如果前面为假的，就不执行后面的调用（解决当index为-1的时候崩溃的bug）
      that.lis[index] && that.lis[index].click();
    }

    // 4. 编辑修改功能
    editTab() {
      // 获取原来的字符串
      var str = this.innerHTML;
      // 双击禁止选定文字
      window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
      this.innerHTML = '<input type="text"/>'; // 添加输入框
      var input = this.children[0]; //获取输入框
      // 设置输入框的属性
      input.value = str;
      input.style.width = '60px';
      input.style.height = '40px';
      input.select(); // 文本框里面的文字处于选定状态
      // 当我们离开文本框就把文本框里面的值给span 
      input.onblur = function() {
          this.parentNode.innerHTML = this.value;
          input.remove();
      };    
      // 键盘弹起
      input.onkeyup = function(e) {
        if (e.keyCode === 13) { // 按下回车也可以把文本框里面的值给span
          // 手动调用表单失去焦点事件  不需要鼠标离开操作
          this.blur(); //span失去焦点，span里面的子元素也失去焦点
        }
      }
    }
}

// 创建对象
new Tab('#tab');